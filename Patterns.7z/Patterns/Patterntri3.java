package Patterns;

public class Patterntri3 {

	public static void main(String[] args) {
		int line=5;int star=9;int space=0;int i,j;
		for( i=1;i<=line;i++)
		{
			for( j=1;j<=space;j++)
			{
				System.out.print(" ");
			}
		for(int k=1;k<=star;k++)
		{
			if((i==1)||k==1||k==star)
		{
			
		System.out.print("*");
	}
		else
			
		{
			System.out.print(" ");
		}
			
			}
		System.out.println();
	star=star-2;
		space++;
		}

	}

}
/*

*********
 *     *
  *   *
   * *
    *

*/