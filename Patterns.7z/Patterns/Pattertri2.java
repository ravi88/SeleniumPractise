package Patterns;

public class Pattertri2 {

	public static void main(String[] args) 
	{
		int line=4;
		int space=0;
		int star=7;
		
		for(int i=1;i<=line;i++)
		{
			for(int j=1;j<=space;j++)
			{
				System.out.print("  ");
			}
			for(int k=1;k<=star;k++)
			{
				System.out.print("* ");
			}
			System.out.println();
			star=star-2;
			space++;
		}
		
		
		
	}

}
  /* 

* * * * * * * 
  * * * * * 
    * * * 
     * 

*/